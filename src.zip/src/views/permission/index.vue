<template>
  <div class="dashboard-container">
    <div class="app-container">
      员工
    </div>
  </div>
</template>

<script>
export default {}
</script>

<style scoped lang="scss">

</style>

